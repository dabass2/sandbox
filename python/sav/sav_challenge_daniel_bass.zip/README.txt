INFO:
This was all tested and working on python version 3.9.5
Any other versions are untested and not guaranteed to work.

HOW TO RUN:
  - Run without debug
      python .\main.py --file dates.csv
  - Run with debug
      python .\main.py --file dates.csv --debug
  - Optional define python version (include --debug for debug information)
      python3 .\main.py --file dates.csv
  - Basic run in the background (include --debug for debug information)
      nohup python .\main.py --file dates.csv &

NOTE:
The script only stops when interrupted. Whether by keyboard interrupt or directly killing the process.